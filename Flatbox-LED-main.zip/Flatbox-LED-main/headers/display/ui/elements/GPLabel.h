#ifndef _GPLABEL_H_
#define _GPLABEL_H_

#include "GPWidget.h"

class GPLabel : public GPWidget {
    public:
        void draw();
};

#endif