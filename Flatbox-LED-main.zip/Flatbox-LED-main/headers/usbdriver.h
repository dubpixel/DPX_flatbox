#ifndef _USB_DRIVER_H_
#define _USB_DRIVER_H_

bool get_usb_mounted(void);
bool get_usb_suspended(void);

#endif // #ifndef _USB_DRIVER_H_