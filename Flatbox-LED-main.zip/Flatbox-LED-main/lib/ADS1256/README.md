# ADS1256

Ported from <https://github.com/CuriousScientist0/ADS1256> (MIT License) to GP2040-CE PicoPeripherals interface.
