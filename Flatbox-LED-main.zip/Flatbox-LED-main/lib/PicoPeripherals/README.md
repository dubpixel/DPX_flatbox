PicoPeripherals Library
-----------------------

Basic implementation of RP2040/Pico-specific I2C and SPI controller interfaces.