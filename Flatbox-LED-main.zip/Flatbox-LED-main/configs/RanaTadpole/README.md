# GP2040 Configuration for the Rana Tadpole

![Rana Tadpole 1](assets/RanaTadpole1.jpg)
![Rana Tadpole 2](assets/RanaTadpole2.jpg)

Basic button setup for the Rana Tadpole.

![Buttons](assets/RanaTadpole_buttons.png)

GitHub repo for the Tadpole:
https://github.com/rana-sylvatica/rana-tadpole