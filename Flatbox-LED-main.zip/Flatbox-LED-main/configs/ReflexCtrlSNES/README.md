# GP2040-CE Configuration for the Reflex CTRL SNES Board by MiSTer Addons


![Reflex Board](assets/ReflexCTRLSNES.jpeg)

Reflex Board
Open source PCB for SNES Controller replacement PCBs

GitHub: https://github.com/misteraddons/Reflex-CTRL
Purchase from: 

MiSTer Addons: https://misteraddons.com/


