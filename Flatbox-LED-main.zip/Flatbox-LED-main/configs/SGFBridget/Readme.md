# GP2040 Configuration for the SGF Bridget

![SGF Logo](https://github.com/OpenStickCommunity/GP2040-CE/blob/main/configs/SGFBridget/assets/SGF_Logo.png)

Configuration for the [SGF Devices Bridget](https://sgfdevices.com/products/sgf-bridget-mx-stickless-controller).  

![SGF Bridget](https://github.com/OpenStickCommunity/GP2040-CE/blob/main/configs/SGFBridget/assets/SGF_Bridget.png)
![SGF Bridget Layout](https://github.com/OpenStickCommunity/GP2040-CE/blob/main/configs/SGFBridget/assets/SGF_Bridget_Layout.jpg)