# GP2040 Configuration for Granola Arcade controllers

![Granola Arcade Logo](https://github.com/OpenStickCommunity/GP2040-CE/blob/main/configs/Granola/assets/granola-logo.png)

Configuration for [Granola Arcade](https://granola.games) controllers. 