# GP2040 Configuration for the Fightboard v3

![Pin Mapping](assets/FightboardV3.jpg)

This configuration is for the Fightboard v3 using the Waveshare RP2040 Zero.

