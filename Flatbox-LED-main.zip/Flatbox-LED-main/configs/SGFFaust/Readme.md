# GP2040 Configuration for the SGF Faust

![SGF Logo](https://github.com/OpenStickCommunity/GP2040-CE/blob/main/configs/SGFFaust/assets/SGF_Logo.png)

Configuration for the [SGF Devices Faust](https://sgfdevices.com/products/sgf-faust-all-button-controller).  

![SGF Faust](https://github.com/OpenStickCommunity/GP2040-CE/blob/main/configs/SGFFaust/assets/SGF_Faust.png)
![SGF Faust Layout](https://github.com/OpenStickCommunity/GP2040-CE/blob/main/configs/SGFFaust/assets/SGF_Faust_Layout.png)
