# GP2040 Configuration for the Open_Core0 WASD

![Open_Core0 WASD](assets/Open_Core0_WASD.jpg)

Basic pin setup for the Open_Core0 WASD.

![Pin Mapping](assets/Open_Core0_WASD_pinout.png)

You can find the full Open_Core0 WASD project over on our hardware section [HERE]()