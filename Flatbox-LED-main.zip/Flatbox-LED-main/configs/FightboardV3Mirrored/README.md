# GP2040 Configuration for the mirrored Fightboard v3

![Pin Mapping](assets/FightboardV3Mirrored.jpg)

This configuration is for the mirrored version of the Fightboard v3 using the Waveshare RP2040 Zero.

