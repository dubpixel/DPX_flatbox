# GP2040 Configuration for the RP2040 Mini Breakout Board

![RP2040 Arcade Board](assets/RP2040MiniBreakoutBoard.jpg)
