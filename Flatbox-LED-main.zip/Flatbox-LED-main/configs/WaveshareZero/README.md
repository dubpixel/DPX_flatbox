# GP2040 Configuration for the Waveshare RP2040 Zero

![Pin Mapping](assets/WaveshareRP2040Zero.png)

Basic pin setup for the Waveshare RP2040 Zero.
